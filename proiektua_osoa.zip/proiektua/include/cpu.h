#ifndef CPU_H
#define CPU_H

#include <stdbool.h>
#include <stdint.h>
#include "prozesuak.h"
#include "memoria.h"

/*
 * CPU egitura sinplea:
 *  - id: CPU zenbaki logikoa
 *  - unekoa: une honetan exekutatzen ari den prozesua (edo NULL)
 *  - mem: memoria fisikorako erreferentzia (aukerakoa; NULL bada ez da memoria-simulaziorik egingo)
 */
struct CPU {
    int id;
    struct PCB *unekoa;
    struct MemoriaFisikoa *mem;
    uint32_t pc;        // Program Counter (helbide birtuala) 
    uint32_t ir;        // Instruction Register 
    uint32_t regs[16];  // 16 erregistro orokor 
    int hasieratua;     // 0: oraindik ez, 1: badago hasieratua 
};

/* CPU bakarra hasieratu */
void cpu_hasieratu(struct CPU *cpu, int id);

/* CPU multzo bat hasieratu (array-a) */
void cpuak_hasieratu(struct CPU *cpuak, int kop);

/* Memoria fisikoa CPU guztiei ezarri (aukerakoa) */
void cpuak_memoria_ezarri(struct CPU *cpuak, int kop, struct MemoriaFisikoa *mem);

/* CPU bakarraren tick-a:
 *  - uneko prozesua badago, denbora_falta-- egiten du
 *  - memoria esleituta badago, tick bakoitzean memoria-sarbide txiki bat simulatzen du
 *  - 0 bada, prozesua TERMINATED egoerara pasa eta askatu
 */
void cpu_tick(struct CPU *cpu);

/* CPU guztiei tick bat aplikatu (array osoari) */
void cpuak_tick(struct CPU *cpuak, int kop);

#endif
