#ifndef SINCRONIZAZIO_H
#define SINCRONIZAZIO_H

#include <pthread.h>

extern pthread_mutex_t mutex;
extern pthread_cond_t cond_clock;
extern pthread_cond_t cond_timer;

extern int done;       // amaituta dauden tenporizadoreen kopurua
extern int tenp_kop;   // tenporizadoreen kopurua guztira

extern struct Tenporizadorea *global_creator_timer;

extern pthread_cond_t cond_creator_done;
extern unsigned long last_creator_tick;
extern int creator_present;
#endif
