#ifndef PROZESU_SORTZAILEA_H
#define PROZESU_SORTZAILEA_H

#include "erlojua.h"
#include "prozesuak.h"
#include "memoria.h"


// Prozesu sortzailearen egitura
struct ProzesuSortzailea {
    struct Erlojua *lotutako_erlojua;  // Erlojuarekin lotura
    struct ProzesuIlara *ilara;        // Prozesu ilara globala
    int azken_pid;                     // Azken sortutako PID-a
    struct MemoriaFisikoa *mem;        // Memoria fisikoaren erreferentzia
    int hurrengo_prog;                 //kargatuko den hurregno programa 
};

// Hasieratu sortzailea
void prozesu_sortzailea_hasieratu(struct ProzesuSortzailea *s, struct Erlojua *e, struct ProzesuIlara *ilara, struct MemoriaFisikoa *mem);


void prozesu_sortzailea_tick(struct ProzesuSortzailea *ps);


#endif
