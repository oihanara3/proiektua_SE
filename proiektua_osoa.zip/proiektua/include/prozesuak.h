#ifndef PROZESUAK_H
#define PROZESUAK_H

#include <stdbool.h>
#include <pthread.h>
#include <stdint.h>

extern pthread_mutex_t mutex_ilara;

/* Egoerak */
typedef enum {
    PROC_NEW,
    PROC_READY,
    PROC_RUNNING,
    PROC_TERMINATED
} ProzesuEgoera;

/* Lehentasunaren bonusak datorren politikarako */
#define BONUS_DOBLE 3   /* Bi dadoak berdinak direnean (+3) */
#define BONUS_STAR  2   /* Gehiketa STAR_SUM bada (+2) */
#define STAR_SUM    7   /* Gehiketa "izarra" (7) */

/* Memoria kudeaketarako egitura: PCB barruko mm eremua */
struct MemoryManagement {
    unsigned int pgb;   /* Orri-taularen helbide fisikoa */
    unsigned int code;  /* kodearen segmentuaren helbide birtuala */
    unsigned int data;  /* datuen segmentuaren helbide birtuala */
};

/* PCB (Process Control Block) egitura */
struct PCB {
    int pid;                 /* Prozesuaren identifikatzailea */
    int dadoa1;              /* Dadoaren lehen balioa */
    int dadoa2;              /* Dadoaren bigarren balioa */
    int gehiketa;            /* Prozesuak lortutako gehiketa jokoan */
    int gehiketa_bonus;      /* gehiketa + bonusak (doble + 7) */
    int itxaron_tickak;      /* READY egoeran daramatzan tick-ak (aging) */
    struct PCB *hurrengoa;   /* Lotura ilara egiteko (hurrengo PCB) */

    int denbora_totala;      /* Prozesuak exekutatu behar duen denbora totala (3.zatian ez da erabiliko)*/
    int denbora_falta;       /* Prozesuak oraindik exekutatu behar duen denbora (3.zatian ez da erabiliko) */
    ProzesuEgoera egoera;    /* Prozesuaren egoera */

    /* 3. zatiko memoria kudeaketa */
    struct MemoryManagement mm;
    uint32_t base_logikoa;   /* Normalean 0 (prozesuaren helbide-espazioaren hasiera) */
    uint32_t mem_tamaina;    /* Byte-tan (prozesuaren espazio logikoa) */
    int orri_kop;            /* Zenbat orri logiko dituen */
    int *orri_taula;         /* orri_logikoa -> orri_fisikoa (frame). -1: ez mapeatuta */
};

/* Prozesu ilara (Process Queue) */
struct ProzesuIlara {
    struct PCB *burua;    /* Ilararen burua */
    struct PCB *bukaera;  /* Ilararen amaiera */
    int luzera;           /* Prozesu kopurua */
};

/* === Funtzioak === */
void prozesu_ausazko_hasiera(unsigned int seed);
struct PCB *sortu_prozesua(int pid);
void print_prozesua(const struct PCB *p);
void desegin_prozesua(struct PCB *p);

/* Ilararen kudeaketa */
void ilara_hasieratu(struct ProzesuIlara *q);
bool ilara_hutsa_da(struct ProzesuIlara *q);
void ilarara_sartu(struct ProzesuIlara *q, struct PCB *p);
struct PCB *ilaratik_atera(struct ProzesuIlara *q);
void ilara_inprimatu(const struct ProzesuIlara *q);
void ilara_posizioak_inprimatu(const struct ProzesuIlara *ilara, bool sartuta);

/* Lehentasunaren kalkulua: gehiketa + bonus + aging(itxaron_tickak) */
int prozesu_lehentasuna(const struct PCB *p);

#endif
