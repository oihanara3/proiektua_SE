#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "prozesuak.h"
#include "erlojua.h"



// Scheduler egitura 
struct Scheduler {
    struct ProzesuIlara *ilara; // prozesuen ilara
    struct Erlojua *erlojua;   
    struct CPU *cpuak;         // CPU egiturak
    int cpu_kop;               // CPU kopurua
};

// Hasieraketa funtzioa
void scheduler_hasieratu(struct Scheduler *s, struct ProzesuIlara *ilara, struct Erlojua *e, struct CPU *cpuak, int cpu_kop);

// Tick bakoitzean (timer-aren seinalea jasotzean)
void scheduler_tick(struct Scheduler *s);

// Ilara ordenatu
void scheduler_ordenatu(struct ProzesuIlara *ilara);



void scheduler_cpuak_tick(struct Scheduler *s);


#endif
