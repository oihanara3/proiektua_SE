#ifndef MEMORIA_H
#define MEMORIA_H

#include <stdint.h>
#include "../prometheus/defines.h"

/*
 * Memoria fisikoaren oinarrizko definizioak
 *  - Helbide-busa: 24 bit 
 *  - Hitzaren tamaina: 4 byte
 *  - Orriaren tamaina: 2^PAGE_SIZE_BITS byte 
 */

#define HITZ_TAMAINA        4                               // 4 byte
#define ORRI_TAMAINA        (1 << PAGE_SIZE_BITS)           // 2^8 = 256
#define MEMORIA_FISIKO_TAM  (1 << 24)                       // 16 MB
#define ORRI_FISIKO_KOP     (MEMORIA_FISIKO_TAM / ORRI_TAMAINA)


/* Kernel-erreserba: RAM hasieran gordetzen dugu (orri-taulak eta abar) */
#define KERNEL_ERRESERBA_TAM   (1 << 20)   
#define KERNEL_HASIERA_HELB    0x000000

/* Kernel-erreserbatik memoria zatiak hartzeko */
uint32_t kernel_allokatu(uint32_t byte_kop);

/*
 * Memoria fisikoa byte bektore soil bat bezala modelatuko dugu.
 * Gerora, hemen gordeko dira:
 *   - Kernelaren erreserba-eremua
 *   - Prozesuen .text eta .data segmentuak
 *   - Orri-taulak, eta abar.
 */
struct MemoriaFisikoa {
    uint8_t *bytes;     // MEMORIA_FISIKO_TAM byte
};

/* Hasieraketa eta askapena */
void memoria_hasieratu(struct MemoriaFisikoa *m);
void memoria_liberatu(struct MemoriaFisikoa *m);

/* Hitzak (4 byte) irakurri/idatzi helbide fisiko batean */
uint32_t memoria_irakurri_hitza(struct MemoriaFisikoa *m, uint32_t helbide_fisikoa);
void memoria_idatzi_hitza(struct MemoriaFisikoa *m, uint32_t helbide_fisikoa, uint32_t balioa);

int frame_hartu(void);
void frame_askatu(int frame);

#endif
