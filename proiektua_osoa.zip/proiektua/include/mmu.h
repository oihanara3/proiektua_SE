#ifndef MMU_H
#define MMU_H

#include <stdint.h>
#include "prozesuak.h"
#include "memoria.h"

uint32_t mmu_itxuli(struct MemoriaFisikoa *mem, struct PCB *p, uint32_t helbide_birtuala);

#endif
