#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "../include/prozesuak.h"

pthread_mutex_t mutex_ilara = PTHREAD_MUTEX_INITIALIZER;

static unsigned int gure_seed = 1;

void prozesu_ausazko_hasiera(unsigned int seed) {
    if (seed == 0) seed = 1;
    gure_seed = seed;
}

static int gure_rand(void) {
    gure_seed = gure_seed * 1103515245u + 12345u;
    return (int)((gure_seed >> 16) & 0x7fff);
}

struct PCB *sortu_prozesua(int pid) {
    struct PCB *p = malloc(sizeof(struct PCB));
    if (!p) return NULL;

    p->pid = pid;
    p->hurrengoa = NULL;

    int r1 = gure_rand();
    int r2 = gure_rand();

    p->dadoa1 = r1 % 6 + 1;
    p->dadoa2 = r2 % 6 + 1;
    p->gehiketa = p->dadoa1 + p->dadoa2;

    int bonus = 0;
    if (p->dadoa1 == p->dadoa2) bonus += BONUS_DOBLE;
    if (p->gehiketa == STAR_SUM) bonus += BONUS_STAR;

    p->gehiketa_bonus = p->gehiketa + bonus;

    p->denbora_totala = (gure_rand() % 5) + 1;
    p->denbora_falta  = p->denbora_totala;

    p->itxaron_tickak = 0;
    p->egoera = PROC_NEW;

    printf("[PROZ] Prozesua sortu da: PID = %d "
           "(dadoak: %d + %d = %d, bonus = %d, "
           "lehentasun_oinarrizkoa = %d,)\n",
           pid, p->dadoa1, p->dadoa2, p->gehiketa,
           bonus, p->gehiketa_bonus);

    return p;
}

void print_prozesua(const struct PCB *p) {
    if (!p) return;
    int leh_osoa = p->gehiketa_bonus + p->itxaron_tickak;
    printf("  [PCB] PID=%d (egoera=%d, denbora_falta=%d, "
           "gehiketa=%d, gehiketa+bonus=%d, itxaron=%d, gehiketa+bonus+aging=%d)\n",
           p->pid, p->egoera, p->denbora_falta,
           p->gehiketa, p->gehiketa_bonus, p->itxaron_tickak, leh_osoa);
}

void desegin_prozesua(struct PCB *p) {
    if (!p) return;
    
    if(p->orri_taula){
        for(int i=0; i<p->orri_kop;i++){
            if(p->orri_taula[i]>=0){
                frame_askatu(p->orri_taula[i]);
                p->orri_taula[i] = -1;
            }
        }
        free(p->orri_taula);
        p->orri_taula = NULL;
    }
        printf("[PROZ] Prozesua desegin da: PID = %d\n", p->pid);

        free(p);
}


void ilara_hasieratu(struct ProzesuIlara *q) {
    q->burua = NULL;
    q->bukaera = NULL;
    q->luzera = 0;
}

bool ilara_hutsa_da(struct ProzesuIlara *q) {
    return q->luzera == 0;
}

void ilarara_sartu(struct ProzesuIlara *q, struct PCB *p) {
    if (!p) return;
    p->hurrengoa = NULL;
    p->egoera = PROC_READY;

    pthread_mutex_lock(&mutex_ilara);

    if (q->bukaera) q->bukaera->hurrengoa = p;
    else q->burua = p;

    q->bukaera = p;
    q->luzera++;

    pthread_mutex_unlock(&mutex_ilara);

    ilara_posizioak_inprimatu(q, false);
    printf("[ILARA] PID %d ilaran sartu da (egoera=READY). Ilararen luzera: %d\n",
           p->pid, q->luzera);
}

void ilara_posizioak_inprimatu(const struct ProzesuIlara *ilara, bool sartuta) {
    if (!ilara || !ilara->burua) return;

    int pos = 1;
    struct PCB *p = ilara->burua;

    if (sartuta) printf("[ILARA] Posizioak ordenatu ondoren:\n");
    else printf("[ILARA] Uneko posizioak prozesu berria gehituta:\n");

    while (p) {
        int leh_osoa = p->gehiketa_bonus + p->itxaron_tickak;
        printf("  Posizioa %d: PID %d (gehiketa = %d, gehiketa+bonus = %d, "
               "itxaron_tickak = %d, gehiketa+bonus+aging = %d, egoera = %d)\n",
               pos, p->pid,
               p->gehiketa,
               p->gehiketa_bonus,
               p->itxaron_tickak,
               leh_osoa,
               p->egoera);
        pos++;
        p = p->hurrengoa;
    }
}

struct PCB *ilaratik_atera(struct ProzesuIlara *q) {
    pthread_mutex_lock(&mutex_ilara);

    if (ilara_hutsa_da(q)) {
        pthread_mutex_unlock(&mutex_ilara);
        return NULL;
    }

    struct PCB *p = q->burua;
    q->burua = p->hurrengoa;
    if (!q->burua) q->bukaera = NULL;

    p->hurrengoa = NULL;
    q->luzera--;

    pthread_mutex_unlock(&mutex_ilara);

    printf("[ILARA] PID %d ilaratik atera da. Luzera: %d\n", p->pid, q->luzera);
    return p;
}

void ilara_inprimatu(const struct ProzesuIlara *q) {
    pthread_mutex_lock(&mutex_ilara);

    printf("[ILARA] Egoera (luzera %d):\n", q->luzera);
    struct PCB *current = q->burua;
    while (current) {
        print_prozesua(current);
        current = current->hurrengoa;
    }

    pthread_mutex_unlock(&mutex_ilara);
}

int prozesu_lehentasuna(const struct PCB *p) {
    if (!p) return -1;
    return p->gehiketa_bonus + p->itxaron_tickak;
}
