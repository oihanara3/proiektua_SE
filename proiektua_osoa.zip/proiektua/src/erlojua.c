#include <stdio.h>
#include <unistd.h>
#include "../include/erlojua.h"
#include "../include/sinkronizazio.h"


/*
 * Erlojua hasieratu.
 *  - tick: 0tik hasiko da
 */
void erlojua_hasieratu(struct Erlojua *e, int maiztasuna_hz) {
    e->tick = 0;
    e->maiztasuna_hz = maiztasuna_hz;
    printf("Erlojua hasieratu da. Maiztasuna: %d Hz\n", maiztasuna_hz);
}

/*
 * Tick berri bat hasi:
 *  - tenporizadore guztiek aurreko tick-eko lana amaitu arte itxaron
 *  - tick balioa handitu eta tenporizadoreei jakinarazi tick berria hasi dela
 */
void erlojua_tick(struct Erlojua *e) {
    pthread_mutex_lock(&mutex);

    // Tenporizadore guztiek amaitu arte itxaron
    while (done < tenp_kop)
     pthread_cond_wait(&cond_clock, &mutex);

    e->tick++;
    printf("\n [CLOCK] Tick %lu hasita (aurreko tick done=%d/%d)\n", e->tick, done, tenp_kop);

    // Hurrengo tickerako prestatu
    done = 0;

    // Tenporizadoreei seinalea bidali tick berriarekin jarrai dezaten
    pthread_cond_broadcast(&cond_timer);
    pthread_mutex_unlock(&mutex);
}

/*
 * Erlojuaren uneko tikka irakurri.
 */
unsigned long erlojua_lortu_tick(struct Erlojua *e) {
    return e->tick;
}
