#include <stdio.h>
#include "../include/tenporizadorea.h"
#include "../include/scheduler.h"
#include "../include/sinkronizazio.h"

void tenporizadorea_hasieratu(struct Tenporizadorea *t,
                              struct Erlojua *e,
                              int seinale_maiztasuna,
                              struct Scheduler *s,
                              struct ProzesuSortzailea *ps,
                              int id) {
    t->seinale_maiztasuna = seinale_maiztasuna;
    t->erlojua = e;
    t->azken_tick = 0;
    t->scheduler = s;
    t->sortzailea = ps;
    t->id = id;

    printf("Tenporizadorea %d hasieratu da. Seinalea %d tick-etan behin bidaliko da.\n",
           id, seinale_maiztasuna);
}

void tenporizadorea_eguneratu(struct Tenporizadorea *t) {
    pthread_mutex_lock(&mutex);

    done++; // tenporizadore honek uneko tika amaitu du
    printf("[TIMER %d] Tick %lu amaitu du (done=%d/%d)\n",
           t->id, erlojua_lortu_tick(t->erlojua), done, tenp_kop);

    // erlojuari tenporizadore bat gehiago libre dagoela jakinarazi
    pthread_cond_signal(&cond_clock);

    // erlojua hurrengo tikera joan arte itxaron
    pthread_cond_wait(&cond_timer, &mutex);

    pthread_mutex_unlock(&mutex);

    if (t->id == 1 && t->scheduler != NULL) {
        scheduler_cpuak_tick(t->scheduler);
    }

    // Tika prozesatu (seinale-maiztasunaren arabera)
    unsigned long une_tick = erlojua_lortu_tick(t->erlojua);
    if (une_tick - t->azken_tick >= (unsigned long)t->seinale_maiztasuna) {
        tenporizadorea_seinalea(t);
        t->azken_tick = une_tick;
    }
}


void tenporizadorea_seinalea(struct Tenporizadorea *t) {
    unsigned long cur_tick = erlojua_lortu_tick(t->erlojua);

    // 2. tenporizadorea: prozesu sortzailea
    if (t->id == 2 && t->sortzailea != NULL) {
        printf("[TIMER %d] Seinalea bidalita prozesu sortzaileari tick %lu-n!\n",
               t->id, cur_tick);

        prozesu_sortzailea_tick(t->sortzailea);

        pthread_mutex_lock(&mutex);
        last_creator_tick = cur_tick;
        pthread_cond_broadcast(&cond_creator_done);
        pthread_mutex_unlock(&mutex);
        return;
    }

    // 1. tenporizadorea: scheduler
    if (t->id == 1 && t->scheduler != NULL) {
        int need_wait = 0;

        pthread_mutex_lock(&mutex);
        if (creator_present && global_creator_timer != NULL) {
            unsigned long last = global_creator_timer->azken_tick;
            int period = global_creator_timer->seinale_maiztasuna;

            if ((cur_tick - last) >= (unsigned long)period) {
                need_wait = 1;
            }
        }
        pthread_mutex_unlock(&mutex);

        if (need_wait) {
            pthread_mutex_lock(&mutex);
            while (last_creator_tick < cur_tick) {
                pthread_cond_wait(&cond_creator_done, &mutex);
            }
            pthread_mutex_unlock(&mutex);
        }

        printf("[TIMER %d] Seinalea bidalita schedulerrari tick %lu-n!\n",
               t->id, cur_tick);
        scheduler_tick(t->scheduler);
    }
}
