#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "../include/cpu.h"
#include "../include/mmu.h"

#include <pthread.h>

/* cpu_tick funtzioa aldi berean 2 harik exekutatzea saihesteko */
static pthread_mutex_t cpu_tick_mutex = PTHREAD_MUTEX_INITIALIZER;


void cpu_hasieratu(struct CPU *cpu, int id) {
    cpu->id = id;
    cpu->unekoa = NULL;
    cpu->mem = NULL;
    cpu->pc = 0;
    cpu->ir = 0;
    for (int i = 0; i < 16; i++) cpu->regs[i] = 0;
    cpu->hasieratua = 0;
}

void cpuak_hasieratu(struct CPU *cpuak, int kop) {
    for (int i = 0; i < kop; i++) {
        cpu_hasieratu(&cpuak[i], i);
    }
}

void cpuak_memoria_ezarri(struct CPU *cpuak, int kop, struct MemoriaFisikoa *mem) {
    for (int i = 0; i < kop; i++) {
        cpuak[i].mem = mem;
    }
}

void cpu_tick(struct CPU *cpu) {
    
    /* cpu_tick-en deialdi konkurrenteak saihestu */
    pthread_mutex_lock(&cpu_tick_mutex);

    if (!cpu || !cpu->unekoa) {
        pthread_mutex_unlock(&cpu_tick_mutex);
        return;
    }

    struct PCB *p = cpu->unekoa;
    if (!cpu->mem) {
        pthread_mutex_unlock(&cpu_tick_mutex);
        return;
    }

    /* Lehenengo aldiz CPU honek prozesu hau exekutatzen badu, PC hasieratu */
    if (cpu->hasieratua == 0) {
        cpu->pc = p->mm.code;  /* .text hasieratik */
        cpu->ir = 0;
        for (int i = 0; i < 16; i++) cpu->regs[i] = 0;
        cpu->hasieratua = 1;

        printf("[CPU %d] PID %d hasieratua: PC=0x%X\n", cpu->id, p->pid, cpu->pc);
    }

    /*AGINDUA LORTU*/
    uint32_t pa = mmu_itxuli(cpu->mem, p, cpu->pc);
    cpu->ir = memoria_irakurri_hitza(cpu->mem, pa);

    /*DESKODETU*/
    uint32_t inst = cpu->ir;
    uint32_t op = (inst >> 28) & 0xF;

    /* exit */
    if (op == 0xF) {
        printf("[CPU %d] PID %d: EXIT (PC=0x%X)\n", cpu->id, p->pid, cpu->pc);

        /* Prozesua amaitu */
        p->egoera = PROC_TERMINATED;
        cpu->unekoa = NULL;
        cpu->hasieratua = 0;

        /* PCB askatu */
        desegin_prozesua(p);

        pthread_mutex_unlock(&cpu_tick_mutex);
        return;
    }

    /* ld: op=0x0 | R=4bit | AAAAAA=24bit (helbide birtuala) */
    if (op == 0x0) {
        uint32_t r = (inst >> 24) & 0xF;
        uint32_t va = inst & 0xFFFFFF;

        uint32_t pa2 = mmu_itxuli(cpu->mem, p, va);
        cpu->regs[r] = memoria_irakurri_hitza(cpu->mem, pa2);

        printf("[CPU %d] PID %d: LD R%d erregistroan,  0x%X helbide birtualarekin\n", cpu->id, p->pid, r, va);

        cpu->pc += 4;
        pthread_mutex_unlock(&cpu_tick_mutex);
        return;
    }

    /* st: op=0x1 | R=4bit | AAAAAA=24bit */
    if (op == 0x1) {
        uint32_t r = (inst >> 24) & 0xF;
        uint32_t va = inst & 0xFFFFFF;

        uint32_t pa2 = mmu_itxuli(cpu->mem, p, va);
        memoria_idatzi_hitza(cpu->mem, pa2, cpu->regs[r]);

        printf("[CPU %d] PID %d: ST R%d-tik  0x%X helbide birtualera\n", cpu->id, p->pid, r, va);

        cpu->pc += 4;
        pthread_mutex_unlock(&cpu_tick_mutex);
        return;
    }

    /* add: op=0x2 | rd=4bit | r1=4bit | r2=4bit | (gainerakoa 0) */
    if (op == 0x2) {
        uint32_t rd = (inst >> 24) & 0xF;
        uint32_t r1 = (inst >> 20) & 0xF;
        uint32_t r2 = (inst >> 16) & 0xF;

        cpu->regs[rd] = cpu->regs[r1] + cpu->regs[r2];

        printf("[CPU %d] PID %d: ADD R%d + R%d, emaitza R%d-n\n", cpu->id, p->pid, r1, r2, rd);

        cpu->pc += 4;
        pthread_mutex_unlock(&cpu_tick_mutex);
        return;
    }

    /* Opcode ezezaguna */
    printf("[CPU %d] PID %d: opcode ezezaguna (inst=0x%08X, PC=0x%X)\n",
           cpu->id, p->pid, inst, cpu->pc);
    cpu->pc += 4;

    pthread_mutex_unlock(&cpu_tick_mutex);
}


void cpuak_tick(struct CPU *cpuak, int kop) {
    for (int i = 0; i < kop; i++) {
        cpu_tick(&cpuak[i]);
    }
}
