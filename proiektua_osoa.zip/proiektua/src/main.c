#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "../include/erlojua.h"
#include "../include/tenporizadorea.h"
#include "../include/prozesuak.h"
#include "../include/prozesu_sortzailea.h"
#include "../include/scheduler.h"
#include "../include/sinkronizazio.h"
#include "../include/cpu.h"
#include "../include/memoria.h"
#include "../include/mmu.h"

#define CPU_KOP 2   // simulazio honetan erabiliko diren CPU kopurua
static struct CPU *g_cpuak = NULL;
static int g_cpu_kop = 0;

// ===================================================
//  HARIEN FUNTZIOAK
// ===================================================
/* ===================================================
 *  MINI PROBA: Memoria + MMU
 * =================================================== */
/* static void mini_proba_memoria_mmu(void) {
    printf("\n=== MINI PROBA (MEMORIA + MMU) ===\n");

    struct MemoriaFisikoa mem;
    memoria_hasieratu(&mem);

    // PCB faltsu bat sortu (MMU probatzeko bakarrik) 
    struct PCB p;
    p.pid = 99;

    // 2 orri logiko mapatuko ditugu 
    p.orri_kop = 2;
    p.orri_taula = (int *)malloc(sizeof(int) * p.orri_kop);
    if (!p.orri_taula) {
        printf("[MINI] Ezin izan da orri-taula allokatu.\n");
        memoria_liberatu(&mem);
        return;
    }

    // Frame bi hartu eta mapatu 
    int f0 = frame_hartu();
    int f1 = frame_hartu();
    if (f0 < 0 || f1 < 0) {
        printf("[MINI] Ez dago frame librerik (f0=%d, f1=%d).\n", f0, f1);
        free(p.orri_taula);
        memoria_liberatu(&mem);
        return;
    }

    p.orri_taula[0] = f0;
    p.orri_taula[1] = f1;

    // 2 helbide logiko probatuko ditugu: orri0 eta orri1 
    uint32_t log0 = 0;                      // orri 0, offset 0
    uint32_t log1 = ORRI_TAMAINA + 4;       // orri 1, offset 4 (hitz bat)

    uint32_t fis0 = mmu_itxuli(&p, log0);
    uint32_t fis1 = mmu_itxuli(&p, log1);

    printf("[MINI] Mapa: log0=0x%X -> fis0=0x%X (frame %d)\n", log0, fis0, f0);
    printf("[MINI] Mapa: log1=0x%X -> fis1=0x%X (frame %d)\n", log1, fis1, f1);

    // Idatzi bi balio eta irakurri berriz 
    uint32_t v0 = 0xAABBCCDD;
    uint32_t v1 = 0x11223344;

    memoria_idatzi_hitza(&mem, fis0, v0);
    memoria_idatzi_hitza(&mem, fis1, v1);

    uint32_t r0 = memoria_irakurri_hitza(&mem, fis0);
    uint32_t r1 = memoria_irakurri_hitza(&mem, fis1);

    printf("[MINI] Irakurrita: r0=0x%X (esperotakoa 0x%X)\n", r0, v0);
    printf("[MINI] Irakurrita: r1=0x%X (esperotakoa 0x%X)\n", r1, v1);

    if (r0 == v0 && r1 == v1) {
        printf("[MINI] ONDO: MMU + Memoria fisikoa koherenteak dira.\n");
    } else {
        printf("[MINI] GAIZKI: balioak ez datoz bat.\n");
    }

    // Garbiketa 
    frame_askatu(f0);
    frame_askatu(f1);
    free(p.orri_taula);
    memoria_liberatu(&mem);

    printf("=== MINI PROBA AMAITUTA ===\n\n");
}
*/
void *erlojua_haria(void *arg) {
    struct Erlojua *e = (struct Erlojua *)arg;

    while (1) {
        erlojua_tick(e);
        /* Tick bakoitzean CPU guztiak exekutatu */
        if (g_cpuak != NULL) {
            cpuak_tick(g_cpuak, g_cpu_kop);
        }

        usleep(300000);
    }
    return NULL;
}

void *tenporizadorea_haria(void *arg) {
    struct Tenporizadorea *t = (struct Tenporizadorea *)arg;

    while (1) {
        tenporizadorea_eguneratu(t);
        usleep(300000);
    }
    return NULL;
}


int main() {
    struct Erlojua erlojua;
    struct Tenporizadorea timer1, timer2;
    struct ProzesuIlara ilara;
    struct ProzesuSortzailea sortzailea;
    struct Scheduler scheduler;
    struct CPU cpuak[CPU_KOP];
    struct MemoriaFisikoa mem;

    // Egitura nagusiak hasieratu
    erlojua_hasieratu(&erlojua, 1);
    ilara_hasieratu(&ilara);
    memoria_hasieratu(&mem);
    cpuak_hasieratu(cpuak, CPU_KOP);
    for (int i = 0; i < CPU_KOP; i++) {
        cpuak[i].mem = &mem;   /* CPUak RAM-era sarbidea izan dezan */
    }

    scheduler_hasieratu(&scheduler, &ilara, &erlojua, cpuak, CPU_KOP);
    prozesu_sortzailea_hasieratu(&sortzailea, &erlojua, &ilara, &mem);
    
    g_cpuak = cpuak;
    g_cpu_kop = CPU_KOP;
    // Bi tenporizadore: scheduler + prozesu sortzailea
    tenp_kop = 2;

    // Timer 1  scheduler
    tenporizadorea_hasieratu(&timer1, &erlojua, 5, &scheduler, NULL, 1);

    // Timer 2  prozesu sortzailea
    global_creator_timer = &timer2;
    creator_present = 1;
    tenporizadorea_hasieratu(&timer2, &erlojua, 2, NULL, &sortzailea, 2);

   // mini_proba_memoria_mmu();
    printf("\n=== SISTEMAREN SIMULAZIOA HASI DA ===\n");

    // Haria sortu: erlojua eta bi tenporizadoreak
    pthread_t haria_erlojua, haria_timer1, haria_timer2;
    pthread_create(&haria_erlojua, NULL, erlojua_haria, &erlojua);
    pthread_create(&haria_timer1, NULL, tenporizadorea_haria, &timer1);
    pthread_create(&haria_timer2, NULL, tenporizadorea_haria, &timer2);

    pthread_join(haria_erlojua, NULL);
    pthread_join(haria_timer1, NULL);
    pthread_join(haria_timer2, NULL);

    return 0;
}
