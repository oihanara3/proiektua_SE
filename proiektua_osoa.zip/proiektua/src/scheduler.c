#include <stdio.h>
#include "../include/scheduler.h"
#include "../include/prozesuak.h"
#include "../include/cpu.h"

/*
 * READY ilaran dauden prozesu guztien itxaron_tickak handitu.
 * Aging mekanismo sinplea: schedulerraren tick bakoitzean, itxaroten daudenek
 * lehentasun eraginkorra irabazten dute.
 */
static void scheduler_eguneratu_aging(struct ProzesuIlara *ilara) {
    struct PCB *p = ilara->burua;
    while (p != NULL) {
        p->itxaron_tickak++;
        p = p->hurrengoa;
    }
}

void scheduler_hasieratu(struct Scheduler *s,
                         struct ProzesuIlara *ilara,
                         struct Erlojua *e,
                         struct CPU *cpuak,
                         int cpu_kop) {
    s->ilara = ilara;
    s->erlojua = e;
    s->cpuak = cpuak;
    s->cpu_kop = cpu_kop;
    printf("[SCHEDULER] Hasieratua.\n");
}

void scheduler_cpuak_tick(struct Scheduler *s) {
    cpuak_tick(s->cpuak, s->cpu_kop);
}

/*
 * Scheduler tick:
 *  - Aging aplikatu: READY ilarako prozesu guztien itxaron_tickak++
 *  - READY ilara ordenatu lehentasun ERAGINKORRAREN arabera (gehiketa_bonus + itxaron_tickak)
 *  - CPU libre bakoitzari READY ilaratik prozesu bat esleitu
 */
void scheduler_tick(struct Scheduler *s) {
    if (s->ilara->burua == NULL)
        return;

    // Aging: READY ilaran dauden guztien itxaron_tickak handitu
    scheduler_eguneratu_aging(s->ilara);

    // READY ilara lehentasun eraginkorraren arabera ordenatu
    scheduler_ordenatu(s->ilara);
    ilara_posizioak_inprimatu(s->ilara, true);

    // CPU libre bakoitzari prozesu bat esleitu
    for (int i = 0; i < s->cpu_kop; ++i) {
        struct CPU *cpu = &s->cpuak[i];

        if (cpu->unekoa != NULL)
            continue;  // CPU hau okupatuta dago

        if (s->ilara->burua == NULL)
            break;     // Ez dago prozesu gehiagorik esleitzeko

        struct PCB *hautatutako = ilaratik_atera(s->ilara);
        if (!hautatutako)
            break;

        int itxaron_zaharra = hautatutako->itxaron_tickak;
        int leh_eraginkorra = hautatutako->gehiketa_bonus + itxaron_zaharra;

        hautatutako->egoera = PROC_RUNNING;
        hautatutako->itxaron_tickak = 0;

        cpu->unekoa = hautatutako;

        cpu->hasieratua = 0;

        printf("[SCHEDULER] PID %d hautatu da eta CPU %d-ra esleitu da "
               "(gehiketa = %d, gehiketa+bonus = %d, itxaron_tickak = %d, "
               "leh_eraginkorra = %d, denbora_falta = %d).\n",
               hautatutako->pid, cpu->id,
               hautatutako->gehiketa,
               hautatutako->gehiketa_bonus,
               itxaron_zaharra,
               leh_eraginkorra,
               hautatutako->denbora_falta);
    }
}

/*
 * READY ilara lehentasunaren arabera ordenatu
 *  - Orain lehentasun ERAGINKORRA erabiltzen da:
 *    gehiketa_bonus + itxaron_tickak (aging)
 *  - Lehentasun eraginkor handiena duen prozesua aurrena.
 */
void scheduler_ordenatu(struct ProzesuIlara *ilara) {
    if (ilara->burua == NULL || ilara->burua->hurrengoa == NULL) {
        return;
    }

    int ordenatua;
    do {
        ordenatua = 1;
        struct PCB *unekoa = ilara->burua;
        struct PCB *aurrekoa = NULL;

        while (unekoa->hurrengoa != NULL) {
            struct PCB *hurrengoa = unekoa->hurrengoa;

            int leh_unekoa =
                unekoa->gehiketa_bonus + unekoa->itxaron_tickak;
            int leh_hurrengoa =
                hurrengoa->gehiketa_bonus + hurrengoa->itxaron_tickak;

            if (leh_unekoa < leh_hurrengoa) {
                if (aurrekoa == NULL)
                    ilara->burua = hurrengoa;
                else
                    aurrekoa->hurrengoa = hurrengoa;

                unekoa->hurrengoa = hurrengoa->hurrengoa;
                hurrengoa->hurrengoa = unekoa;

                ordenatua = 0;
                aurrekoa = hurrengoa;
            } else {
                aurrekoa = unekoa;
                unekoa = unekoa->hurrengoa;
            }
        }
    } while (!ordenatua);

    // Bukaera eguneratu
    struct PCB *p = ilara->burua;
    while (p->hurrengoa != NULL) {
        p = p->hurrengoa;
    }
    ilara->bukaera = p;
}
