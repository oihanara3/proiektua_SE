#include <stdio.h>
#include <stdlib.h>
#include "../include/memoria.h"

/* Kernel-erreserban hurrengo libre dagoen helbidea */
static uint32_t kernel_next_free = 0;


static int frame_erabilita[ORRI_FISIKO_KOP];

/*
 * Memoria fisikoa hasieratu.
 *   - MEMORIA_FISIKO_TAM byte-eko bufferra alokatu.
 */
void memoria_hasieratu(struct MemoriaFisikoa *m) {
    if (!m) return;
    for (int i = 0; i < ORRI_FISIKO_KOP; i++) frame_erabilita[i] = 0;

    m->bytes = malloc(MEMORIA_FISIKO_TAM);
    if (!m->bytes) {
        fprintf(stderr, "[MEM] Errorea: ezin izan da memoria fisikoa alokatu.\n");
        exit(EXIT_FAILURE);
    }

    for (uint32_t i = 0; i < MEMORIA_FISIKO_TAM; ++i) {
        m->bytes[i] = 0;
    }
        /* Kernel-erreserba markatu: frame hauek ez dira user prozesuentzat izango */
    kernel_next_free = 0;

    int kernel_frames = (int)(KERNEL_ERRESERBA_TAM / ORRI_TAMAINA);
    for (int i = 0; i < kernel_frames; i++) {
        frame_erabilita[i] = 1;
    }

    printf("[MEM] Memoria fisikoa hasieratu da (%d byte).\n", MEMORIA_FISIKO_TAM);
}

/*
 * Memoria fisikoa liberatu.
 */
void memoria_liberatu(struct MemoriaFisikoa *m) {
    if (!m) return;
    if (m->bytes) {
        free(m->bytes);
        m->bytes = NULL;
    }
}

/*
 * Hitz bat (4 byte) irakurri helbide fisiko batetik.
 *   - Helbidea 4ren multiploa dela suposatzen dugu.
 */
uint32_t memoria_irakurri_hitza(struct MemoriaFisikoa *m, uint32_t helbide_fisikoa) {
    if (!m || !m->bytes) return 0;

    if (helbide_fisikoa + HITZ_TAMAINA > MEMORIA_FISIKO_TAM) {
        fprintf(stderr, "[MEM] Errorea: helbide fisikoa kanpoan dago (read).\n");
        return 0;
    }

    uint32_t balioa = 0;

    balioa |= (uint32_t)m->bytes[helbide_fisikoa]     << 24;
    balioa |= (uint32_t)m->bytes[helbide_fisikoa + 1] << 16;
    balioa |= (uint32_t)m->bytes[helbide_fisikoa + 2] << 8;
    balioa |= (uint32_t)m->bytes[helbide_fisikoa + 3];

    return balioa;
}

/*
 * Hitz bat (4 byte) idatzi helbide fisiko batean.
 */
void memoria_idatzi_hitza(struct MemoriaFisikoa *m, uint32_t helbide_fisikoa, uint32_t balioa) {
    if (!m || !m->bytes) return;

    if (helbide_fisikoa + HITZ_TAMAINA > MEMORIA_FISIKO_TAM) {
        fprintf(stderr, "[MEM] Errorea: helbide fisikoa kanpoan dago (write).\n");
        return;
    }

    m->bytes[helbide_fisikoa]     = (balioa >> 24) & 0xFF;
    m->bytes[helbide_fisikoa + 1] = (balioa >> 16) & 0xFF;
    m->bytes[helbide_fisikoa + 2] = (balioa >> 8)  & 0xFF;
    m->bytes[helbide_fisikoa + 3] =  balioa        & 0xFF;
}
int frame_hartu(void) {
    for (int i = 0; i < ORRI_FISIKO_KOP; i++) {
        if (frame_erabilita[i] == 0) {
            frame_erabilita[i] = 1;
            return i;
        }
    }
    return -1;
}

void frame_askatu(int frame) {
    if (frame >= 0 && frame < ORRI_FISIKO_KOP) {
        frame_erabilita[frame] = 0;
    }
}

uint32_t kernel_allokatu(uint32_t byte_kop) {
    /* 4 byte-ko lerrokapena (hitza) */
    if (byte_kop % 4 != 0) {
        byte_kop += 4 - (byte_kop % 4);
    }

    uint32_t addr = kernel_next_free;
    kernel_next_free += byte_kop;

    if (kernel_next_free > KERNEL_ERRESERBA_TAM) {
        fprintf(stderr, "[MEM][KERNEL] Ez dago lekurik kernel erreserban (eskatu=%u)\n", byte_kop);
        exit(EXIT_FAILURE);
    }

    /* Helbide fisikoa bueltatzen dugu (RAM hasieratik) */
    return KERNEL_HASIERA_HELB + addr;
}


