#include <stdio.h>
#include <stdint.h>
#include "../include/mmu.h"
#include "../include/defines.h"

/*
 * MMU itzulpena:
 *  - Helbide birtuala prozesuaren base_logikoa-tik erlatibizatzen da
 *  - vpn = (va - base) / ORRI_TAMAINA
 *  - PTE irakurtzen da p->mm.pgb (PTBR) erabiliz memoria fisikotik
 *  - fallback: p->orri_taula (orain arteko modua) pgb=0 bada
 */
uint32_t mmu_itxuli(struct MemoriaFisikoa *mem, struct PCB *p, uint32_t va) {
    if (!p) return 0;

    /* Helbide birtualaren egiaztapena */
    if (va < p->base_logikoa || va >= (p->base_logikoa + p->mem_tamaina)) {
        printf("[MMU][ERROR] PID %d: VA kanpoan (va=0x%X, base=0x%X, tam=%u)\n",
               p->pid, va, p->base_logikoa, p->mem_tamaina);
        return 0;
    }

    uint32_t rel = va - p->base_logikoa;
    uint32_t vpn = rel / ORRI_TAMAINA;
    uint32_t off = rel % ORRI_TAMAINA;

    if ((int)vpn >= p->orri_kop) {
        printf("[MMU][ERROR] PID %d: VPN kanpoan (vpn=%u)\n", p->pid, vpn);
        return 0;
    }

    /* 1) Enuntziatuaren modua: PGB/PTBR + memoria fisikoan orri-taula */
    if (p->mm.pgb != 0 && mem != NULL) {
        uint32_t pte_addr = p->mm.pgb + vpn * 4u;
        uint32_t frame_u = memoria_irakurri_hitza(mem, pte_addr);

        if (frame_u == 0xFFFFFFFFu) {
            printf("[MMU][ERROR] PID %d: page fault (vpn=%u ez mapatua)\n", p->pid, vpn);
            return 0;
        }

        return frame_u * ORRI_TAMAINA + off;
    }

    /* 2) Fallback zaharra: p->orri_taula */
    if (!p->orri_taula) {
        printf("[MMU][ERROR] PID %d: ez dago orri_taularik eta pgb=0\n", p->pid);
        return 0;
    }

    int frame = p->orri_taula[vpn];
    if (frame < 0) {
        printf("[MMU][ERROR] PID %d: page fault (vpn=%u ez mapatua)\n", p->pid, vpn);
        return 0;
    }

    return (uint32_t)frame * ORRI_TAMAINA + off;
}
