#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>

#include "../include/prozesu_sortzailea.h"
#include "../include/prozesuak.h"
#include "../include/memoria.h"
#include "../include/defines.h"
#include "../include/mmu.h"


/* Lerro batetik hex 32-bit bat irakurtzen saiatzen da */
static int lerro_hex_irakurri(const char *line, uint32_t *out) {
    while (*line == ' ' || *line == '\t') line++;
    if (*line == '\0' || *line == '\n' || *line == '#') return 0;
    return (sscanf(line, "%x", out) == 1);
}

/*
 * .elf fitxategiaren formatua:
 *  1) ".text XXXXX"
 *  2) ".data YYYYY"
 *  3) instrukzioak (32-bit hex) exit = F0000000 arte
 *  4) datuak (32-bit hex) EOF arte
 */
static int elf_kargatu(const char *path,
                       uint32_t *code_start, uint32_t *data_start,
                       uint32_t **code, int *code_n,
                       uint32_t **data, int *data_n) {
    FILE *f = fopen(path, "r");
    if (!f) return -1;

    char line[128];

    if (!fgets(line, sizeof(line), f)) { fclose(f); return -1; }
    if (sscanf(line, ".text %x", code_start) != 1) { fclose(f); return -1; }

    if (!fgets(line, sizeof(line), f)) { fclose(f); return -1; }
    if (sscanf(line, ".data %x", data_start) != 1) { fclose(f); return -1; }

    int capC = 64, capD = 64;
    *code = (uint32_t*)malloc(sizeof(uint32_t) * capC);
    *data = (uint32_t*)malloc(sizeof(uint32_t) * capD);
    *code_n = 0;
    *data_n = 0;

    /* Instrukzioak */
    while (fgets(line, sizeof(line), f)) {
        uint32_t w;
        if (!lerro_hex_irakurri(line, &w)) continue;

        if (*code_n >= capC) {
            capC *= 2;
            *code = (uint32_t*)realloc(*code, sizeof(uint32_t) * capC);
        }
        (*code)[(*code_n)++] = w;

        if (w == 0xF0000000u) break; /* exit */
    }

    /* Datuak */
    while (fgets(line, sizeof(line), f)) {
        uint32_t w;
        if (!lerro_hex_irakurri(line, &w)) continue;

        if (*data_n >= capD) {
            capD *= 2;
            *data = (uint32_t*)realloc(*data, sizeof(uint32_t) * capD);
        }
        (*data)[(*data_n)++] = w;
    }

    fclose(f);
    return 0;
}

static void prozesuari_memoria_esleitu(struct PCB *p, uint32_t base_logikoa, uint32_t mem_tamaina) {
    if (!p) return;

    p->base_logikoa = base_logikoa;
    p->mem_tamaina = mem_tamaina;

    p->orri_kop = (p->mem_tamaina + ORRI_TAMAINA - 1) / ORRI_TAMAINA;

    p->orri_taula = (int *)malloc(sizeof(int) * p->orri_kop);
    if (!p->orri_taula) {
        printf("[SORTZAILEA][ERROR] Ezin da orri-taula allokatu (PID=%d)\n", p->pid);
        p->orri_kop = 0;
        return;
    }

    for (int i = 0; i < p->orri_kop; i++) p->orri_taula[i] = -1;

    for (int i = 0; i < p->orri_kop; i++) {
        int f = frame_hartu();
        if (f < 0) {
            printf("[SORTZAILEA][ERROR] Ez dago frame librerik (PID=%d, orri=%d)\n", p->pid, i);
            break;
        }
        p->orri_taula[i] = f;
    }

    printf("[SORTZAILEA] PID %d: memoria esleituta (base=0x%X, mem_tamaina=%u, orri_kop=%d)\n",
           p->pid, p->base_logikoa, p->mem_tamaina, p->orri_kop);
}


void prozesu_sortzailea_hasieratu(struct ProzesuSortzailea *s,
                                  struct Erlojua *e,
                                  struct ProzesuIlara *ilara,
                                  struct MemoriaFisikoa *mem) {
    s->lotutako_erlojua = e;
    s->ilara = ilara;
    s->azken_pid = 0;
    s->mem = mem;
    s->hurrengo_prog = 1;

    unsigned int seed = (unsigned int)time(NULL) ^ (unsigned int)getpid();
    prozesu_ausazko_hasiera(seed);

    printf("[SORTZAILEA] Ausazko hazia hasieratu da: %u\n", seed);
}


void prozesu_sortzailea_tick(struct ProzesuSortzailea *ps) {
    if (!ps) return;

    /*1) progXXX.elf kargatzen saiatu */
    char path[256];
    snprintf(path, sizeof(path), "prometheus/prog%03d.elf", ps->hurrengo_prog);

    uint32_t code_start = 0, data_start = 0;
    uint32_t *code = NULL, *data = NULL;
    int code_n = 0, data_n = 0;

    int elf_ok = (elf_kargatu(path, &code_start, &data_start, &code, &code_n, &data, &data_n) == 0);

    /* PID */
    ps->azken_pid++;
    struct PCB *p = sortu_prozesua(ps->azken_pid);
    if (!p) {
        if (elf_ok) { free(code); free(data); }
        return;
    }

    if (elf_ok && ps->mem) {
        /* 2) PCB-ko mm eremuak bete (enuntziatuak eskatzen du) */
        p->mm.code = code_start;
        p->mm.data = data_start;
        p->mm.pgb  = 0; /* oraingoz ez dugu kernel-eko orri-taula fisikoa (hurrengo pausoa) */

        /* 3) Prozesuaren espazio logikoa kalkulatu */
        uint32_t data_bytes = (uint32_t)data_n * 4u;
        uint32_t base = (code_start / ORRI_TAMAINA) * ORRI_TAMAINA;
        uint32_t end  = data_start + data_bytes;

        if (end < base) end = base; /* segurtasun txikia */

        uint32_t mem_tam = end - base;
        if (mem_tam == 0) mem_tam = ORRI_TAMAINA;

        /*4) Memoria esleitu (zahar moduan, orri_taula + frameak)  */
        prozesuari_memoria_esleitu(p, base, mem_tam);

        /* 4.5) Kernel erreserban orri-taula fisikoa sortu (pgb / PTBR) */
        p->mm.pgb = kernel_allokatu((uint32_t)p->orri_kop * 4u);

        for (int i = 0; i < p->orri_kop; i++) {
            uint32_t frame_u = 0xFFFFFFFFu;

            if (p->orri_taula && p->orri_taula[i] >= 0) {
                frame_u = (uint32_t)p->orri_taula[i];
            }

            memoria_idatzi_hitza(
                ps->mem,
                p->mm.pgb + (uint32_t)i * 4u,
                frame_u
            );
        }

        /*5) .text eta .data kopiatu memoria fisikora (mmu_itxuli zaharra erabilita) */
        for (int i = 0; i < code_n; i++) {
            uint32_t va = code_start + (uint32_t)i * 4u;
            uint32_t pa = mmu_itxuli(ps-> mem, p, va);
            memoria_idatzi_hitza(ps->mem, pa, code[i]);
        }

        for (int i = 0; i < data_n; i++) {
            uint32_t va = data_start + (uint32_t)i * 4u;
            uint32_t pa = mmu_itxuli(ps->mem, p, va);
            memoria_idatzi_hitza(ps->mem, pa, data[i]);
        }

        printf("[LOADER] PID %d kargatuta: %s (.text=0x%X, .data=0x%X)\n",
               p->pid, path, code_start, data_start);

        free(code);
        free(data);

        ps->hurrengo_prog++;
        if (ps->hurrengo_prog > 999) ps->hurrengo_prog = 0;

    } else {
        /*ELF ez badago: aurreko portaera mantendu (aurrerapen segurua)*/
        prozesuari_memoria_esleitu(p, 0, 1024);
    }

    p->egoera = PROC_READY;
    ilarara_sartu(ps->ilara, p);
}
