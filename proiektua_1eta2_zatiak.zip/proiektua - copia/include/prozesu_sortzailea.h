#ifndef PROZESU_SORTZAILEA_H
#define PROZESU_SORTZAILEA_H

#include "erlojua.h"
#include "prozesuak.h"

// Prozesu sortzailearen egitura
struct ProzesuSortzailea {
    struct Erlojua *lotutako_erlojua;  // Erlojuarekin lotura
    struct ProzesuIlara *ilara;        // Prozesu ilara globala
    int azken_pid;                     // Azken sortutako PID-a
};

// Hasieratu sortzailea
void prozesu_sortzailea_hasieratu(struct ProzesuSortzailea *s,
                                  struct Erlojua *e,
                                  struct ProzesuIlara *ilara);


void prozesu_sortzailea_tick(struct ProzesuSortzailea *ps);


#endif
