#ifndef CPU_H
#define CPU_H

#include "prozesuak.h"

/*
 * CPU egitura sinplea:
 *  - id: CPU zenbaki logikoa
 *  - unekoa: une honetan exekutatzen ari den prozesua (edo NULL)
 */
struct CPU {
    int id;
    struct PCB *unekoa;
};

/* CPU bakarra hasieratu */
void cpu_hasieratu(struct CPU *cpu, int id);

/* CPU multzo bat hasieratu (array-a) */
void cpuak_hasieratu(struct CPU *cpuak, int kop);

/* CPU bakarraren tick-a:
 *  - uneko prozesua badago, denbora_gelditua-- egiten du
 *  - 0 edo gutxiago bada, prozesua TERMINATED egoerara pasa eta askatu
 */
void cpu_tick(struct CPU *cpu);

/* CPU guztiei tick bat aplikatu (array osoari) */
void cpuak_tick(struct CPU *cpuak, int kop);

#endif
