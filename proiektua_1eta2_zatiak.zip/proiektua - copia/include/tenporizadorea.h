#ifndef TENPORIZADOREA_H
#define TENPORIZADOREA_H

#include "erlojua.h"
#include "prozesu_sortzailea.h"
#include "scheduler.h"

// ===================================================
//  TENPORIZADOREA (TIMER)
// ===================================================

// Timer sinplearen egitura: erlojuarekin lotuta dago
struct Tenporizadorea {
    int seinale_maiztasuna;     // Zenbat tick-etan behin bidaltzen duen seinalea
    struct Erlojua *erlojua;    // Erloju globalarekin lotura
    unsigned long azken_tick;   // Azken seinalearen tick-a
    struct Scheduler *scheduler; // Scheduler-arekin lotura (gehitu behar da)
    struct ProzesuSortzailea *sortzailea; // Prozesu sortzailearekin lotura (gehitu behar da)
    int id;                     // Tenporizadorearen identifikatzailea
};

// ===================================================
//  FUNTZIOAK
// ===================================================

// Tenporizadorea hasieratu
void tenporizadorea_hasieratu(struct Tenporizadorea *t, struct Erlojua *e, int seinale_maiztasuna, struct Scheduler *s,  struct ProzesuSortzailea *ps, int id);

// Tenporizadorearen funtzio nagusia: tick berria iritsi den bakoitzean egiaztatu
void tenporizadorea_eguneratu(struct Tenporizadorea *t);

// Seinalea bidaltzen duenean zer egin (simulazioa)
void tenporizadorea_seinalea(struct Tenporizadorea *t);

#endif
