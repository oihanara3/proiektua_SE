#ifndef ERLOJUA_H
#define ERLOJUA_H

// ===================================================
//  ERLOJUA (CLOCK)
// ===================================================

// Erlojuaren egitura: sistemaren denbora eta maiztasuna gordetzen ditu
struct Erlojua {
    unsigned long tick;   // Uneko tick kopurua (zenbat ziklo pasa diren)
    int maiztasuna_hz;    // Erlojuaren maiztasuna (Hz) - konfigurazioko parametroa
};

// ===================================================
//  FUNTZIOAK
// ===================================================

// Erlojua hasieratu
void erlojua_hasieratu(struct Erlojua *e, int maiztasuna_hz);

// Tick berri bat sortu (ziklo bat pasa dela simulatu)
void erlojua_tick(struct Erlojua *e);

// Uneko tick kopurua itzuli
unsigned long erlojua_lortu_tick(struct Erlojua *e);

#endif
