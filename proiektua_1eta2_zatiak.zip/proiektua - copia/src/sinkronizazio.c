#include "../include/sinkronizazio.h"

// ===================================================
//  SINKRONIZAZIO PRIMITIBOAK ETA ALDAGAIA GLOBALAK
// ===================================================

// Erlojuaren eta tenporizadoreen arteko sinkronizazioa
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_clock = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond_timer = PTHREAD_COND_INITIALIZER;

// Tick bakoitzean zenbat tenporizadorek amaitu duten adierazteko
int done = 0;
// Sistema abiaraztean zenbat tenporizadore dauden (main-en ezartzen da)
int tenp_kop = 1;

// Sortzaile/scheduler arteko sinkronizaziorako
pthread_cond_t cond_creator_done = PTHREAD_COND_INITIALIZER;
unsigned long last_creator_tick = 0;
int creator_present = 0;

// Sortzaileari lotutako tenporizadore globalerako erakuslea
struct Tenporizadorea *global_creator_timer = NULL;
