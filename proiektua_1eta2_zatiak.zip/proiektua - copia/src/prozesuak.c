#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "../include/prozesuak.h"

pthread_mutex_t mutex_ilara = PTHREAD_MUTEX_INITIALIZER;

/* =======================================================
 *  AUSAZKO SORTZAILE SINPLE PROPIOA
 *  (C-ko rand() erabili beharrean)
 * ======================================================= */

static unsigned int gure_seed = 1;

/*
 * Gure ausazko sortzailearen hazia hasieratu.
 * 0 jasoz gero, 1 erabiliko da (0 ez uzteko).
 */
void prozesu_ausazko_hasiera(unsigned int seed) {
    if (seed == 0) seed = 1;
    gure_seed = seed;
}

/*
 * Gure ausazko funtzioa: LCG (Linear Congruential Generator) sinple bat.
 * 0..32767 tarteko balio pseudo-aleatorioak itzultzen ditu.
 */
static int gure_rand(void) {
    // LCG klasikoa: x = x * a + c (mod 2^32)
    gure_seed = gure_seed * 1103515245u + 12345u;
    return (int)((gure_seed >> 16) & 0x7fff);  // 0..32767
}

/* =======================================================
 *  PCB FUNTZIOAK
 * ======================================================= */

/*
 * PCB bat sortu (PID-a kanpotik jasotzen da).
 * Bi dado simulatzen dira (1..6) eta horien batura erabiltzen da lehentasunerako.
 * Gainera, exekuzio-denbora osoa eta gelditzen dena ausaz ezartzen dira.
 * Orain:
 *  - Bonus gehigarriak: dobleak (+3) eta STAR_SUM (7) (+2)
 *  - lehentasun_oinarrizkoa = gehiketa + bonusak
 *  - itxaron_tickak = 0 (aging-erako hasierako balioa)
 */
struct PCB *sortu_prozesua(int pid) {
    struct PCB *p = malloc(sizeof(struct PCB));
    if (!p) return NULL;

    p->pid = pid;
    p->hurrengoa = NULL;

    // Gure ausazko balioak: dadoen bi jaurtiketa (1-6 tartekoak)
    int r1 = gure_rand();
    int r2 = gure_rand();

    p->dadoa1 = r1 % 6 + 1;
    p->dadoa2 = r2 % 6 + 1;
    p->gehiketa = p->dadoa1 + p->dadoa2;

    // Lehentasun bonusak kalkulatu
    int bonus = 0;

    // Dado biak berdinak badira → BONUS_DOBLE
    if (p->dadoa1 == p->dadoa2) {
        bonus += BONUS_DOBLE;
    }

    // Gehiketa izar-balioa bada (STAR_SUM = 7) → BONUS_STAR
    if (p->gehiketa == STAR_SUM) {
        bonus += BONUS_STAR;
    }

    p->gehiketa_bonus = p->gehiketa + bonus;

    // Exekuzio-denbora osoa (adibidez 1 eta 5 tick artean)
    p->denbora_totala = (gure_rand() % 5) + 1;
    p->denbora_falta = p->denbora_totala;

    // Aging-erako hasierako balioa: oraindik ez du itxaron
    p->itxaron_tickak = 0;

    // Hasierako egoera: NEW (READY-ra pasatuko da ilaran sartzerakoan)
    p->egoera = PROC_NEW;

    printf("[PROZ] Prozesua sortu da: PID = %d "
           "(dadoak: %d + %d = %d, bonus = %d, "
           "lehentasun_oinarrizkoa = %d, denbora_totala = %d)\n",
           pid, p->dadoa1, p->dadoa2, p->gehiketa,
           bonus, p->gehiketa_bonus, p->denbora_totala);

    return p;
}

/* PCB informazioa inprimatu (diagnostikorako) */
void print_prozesua(const struct PCB *p) {
    if (!p) return;
    int leh_eraginkorra = p->gehiketa_bonus + p->itxaron_tickak;
    printf("  [PCB] PID = %d (egoera = %d, denbora_falta = %d, "
           "gehiketa = %d, gehiketa+bonus = %d, itxaron = %d, leh_erag = %d)\n",
           p->pid, p->egoera, p->denbora_falta,
           p->gehiketa, p->gehiketa_bonus,
           p->itxaron_tickak, leh_eraginkorra);
}

/* PCB askatu (free) */
void desegin_prozesua(struct PCB *p) {
    if (p) {
        printf("[PROZ] Prozesua desegin da: PID = %d\n", p->pid);
        free(p);
    }
}

/* =======================================================
 *  ILARA FUNTZIOAK
 * ======================================================= */

void ilara_hasieratu(struct ProzesuIlara *q) {
    q->burua = NULL;
    q->bukaera = NULL;
    q->luzera = 0;
}

bool ilara_hutsa_da(struct ProzesuIlara *q) {
    return q->luzera == 0;
}

/*
 * Prozesu bat ilararen amaieran gehitu (FIFO).
 * Muturrean READY egoerara pasatzen da.
 */
void ilarara_sartu(struct ProzesuIlara *q, struct PCB *p) {
    if (!p) return;
    p->hurrengoa = NULL;
    p->egoera = PROC_READY;

    pthread_mutex_lock(&mutex_ilara);

    if (q->bukaera) {
        q->bukaera->hurrengoa = p;
    } else {
        q->burua = p;
    }
    q->bukaera = p;
    q->luzera++;

    pthread_mutex_unlock(&mutex_ilara);

    ilara_posizioak_inprimatu(q, false);
    printf("[ILARA] PID %d ilaran sartu da (egoera=READY). Ilararen luzera: %d\n",
           p->pid, q->luzera);
}

/*
 * Ilararen egoera inprimatu.
 *  - sartuta == false → prozesu berria gehitu ondoren
 *  - sartuta == true  → scheduler_ordenatu ondoren (lehentasunekin)
 */
void ilara_posizioak_inprimatu(const struct ProzesuIlara *ilara,
                               bool sartuta) {
    if (!ilara || !ilara->burua) return;

    int pos = 1;
    struct PCB *p = ilara->burua;

    if (sartuta)
        printf("[ILARA] Posizioak ordenatu ondoren:\n");
    else
        printf("[ILARA] Uneko posizioak prozesu berria gehituta:\n");

    while (p) {
        int leh_eraginkorra = p->gehiketa_bonus + p->itxaron_tickak;
        printf("  Posizioa %d: PID %d (gehiketa = %d, gehiketa+bonus = %d, "
               "itxaron_tickak = %d, leh_eraginkorra = %d, egoera = %d)\n",
               pos, p->pid,
               p->gehiketa,
               p->gehiketa_bonus,
               p->itxaron_tickak,
               leh_eraginkorra,
               p->egoera);
        pos++;
        p = p->hurrengoa;
    }
}

struct PCB *ilaratik_atera(struct ProzesuIlara *q) {
    pthread_mutex_lock(&mutex_ilara);

    if (ilara_hutsa_da(q)) {
        pthread_mutex_unlock(&mutex_ilara);
        return NULL;
    }

    struct PCB *p = q->burua;
    q->burua = p->hurrengoa;
    if (!q->burua)
        q->bukaera = NULL;

    p->hurrengoa = NULL;
    q->luzera--;

    pthread_mutex_unlock(&mutex_ilara);

    printf("[ILARA] PID %d ilaratik atera da. Luzera: %d\n",
           p->pid, q->luzera);
    return p;
}

void ilara_inprimatu(const struct ProzesuIlara *q) {
    pthread_mutex_lock(&mutex_ilara);

    printf("[ILARA] Egoera (luzera %d):\n", q->luzera);
    struct PCB *current = q->burua;
    while (current) {
        print_prozesua(current);
        current = current->hurrengoa;
    }

    pthread_mutex_unlock(&mutex_ilara);
}
