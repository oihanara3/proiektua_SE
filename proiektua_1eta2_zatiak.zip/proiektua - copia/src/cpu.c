#include <stdio.h>
#include "../include/cpu.h"
#include "../include/prozesuak.h"

/* CPU bakarra hasieratu */
void cpu_hasieratu(struct CPU *cpu, int id) {
    cpu->id = id;
    cpu->unekoa = NULL;
}

/* CPU multzoa hasieratu */
void cpuak_hasieratu(struct CPU *cpuak, int kop) {
    for (int i = 0; i < kop; ++i) {
        cpu_hasieratu(&cpuak[i], i);
    }
}

/* CPU bakarraren tick-a */
void cpu_tick(struct CPU *cpu) {
    struct PCB *p = cpu->unekoa;
    if (!p) return;  // CPU hau libre dago

    // Tick bat lan egin: denbora_gelditua murriztu
    p->denbora_falta--;

    printf("[CPU %d] PID %d exekutatzen (geratzen %d tick)\n",
           cpu->id, p->pid, p->denbora_falta);

    // Amaitu bada, TERMINATED egoerara pasa eta prozesua askatu
    if (p->denbora_falta <= 0) {
        p->egoera = PROC_TERMINATED;
        printf("[CPU %d] PID %d TERMINATED egoerara pasa da.\n",
               cpu->id, p->pid);
        desegin_prozesua(p);
        cpu->unekoa = NULL;
    }
}

/* CPU guztiak tick batean exekutatu */
void cpuak_tick(struct CPU *cpuak, int kop) {
    for (int i = 0; i < kop; ++i) {
        cpu_tick(&cpuak[i]);
    }
}
