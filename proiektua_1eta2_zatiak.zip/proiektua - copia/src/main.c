#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "../include/erlojua.h"
#include "../include/tenporizadorea.h"
#include "../include/prozesuak.h"
#include "../include/prozesu_sortzailea.h"
#include "../include/scheduler.h"
#include "../include/sinkronizazio.h"
#include "../include/cpu.h"

#define CPU_KOP 2   // simulazio honetan erabiliko diren CPU kopurua

// ===================================================
//  HARIEN FUNTZIOAK
// ===================================================

void *erlojua_haria(void *arg) {
    struct Erlojua *e = (struct Erlojua *)arg;

    while (1) {
        erlojua_tick(e);
        usleep(300000);
    }
    return NULL;
}

void *tenporizadorea_haria(void *arg) {
    struct Tenporizadorea *t = (struct Tenporizadorea *)arg;

    while (1) {
        tenporizadorea_eguneratu(t);
        usleep(300000);
    }
    return NULL;
}

// ===================================================
//  MAIN
// ===================================================

int main() {
    struct Erlojua erlojua;
    struct Tenporizadorea timer1, timer2;
    struct ProzesuIlara ilara;
    struct ProzesuSortzailea sortzailea;
    struct Scheduler scheduler;
    struct CPU cpuak[CPU_KOP];

    // Egitura nagusiak hasieratu
    erlojua_hasieratu(&erlojua, 1);
    ilara_hasieratu(&ilara);
    cpuak_hasieratu(cpuak, CPU_KOP);
    scheduler_hasieratu(&scheduler, &ilara, &erlojua, cpuak, CPU_KOP);
    prozesu_sortzailea_hasieratu(&sortzailea, &erlojua, &ilara);

    // Bi tenporizadore: scheduler + prozesu sortzailea
    tenp_kop = 2;

    // Timer 1  scheduler
    tenporizadorea_hasieratu(&timer1, &erlojua, 5, &scheduler, NULL, 1);

    // Timer 2  prozesu sortzailea
    global_creator_timer = &timer2;
    creator_present = 1;
    tenporizadorea_hasieratu(&timer2, &erlojua, 2, NULL, &sortzailea, 2);

    printf("\n=== SISTEMAREN SIMULAZIOA HASI DA ===\n");

    // Haria sortu: erlojua eta bi tenporizadoreak
    pthread_t haria_erlojua, haria_timer1, haria_timer2;
    pthread_create(&haria_erlojua, NULL, erlojua_haria, &erlojua);
    pthread_create(&haria_timer1, NULL, tenporizadorea_haria, &timer1);
    pthread_create(&haria_timer2, NULL, tenporizadorea_haria, &timer2);

    pthread_join(haria_erlojua, NULL);
    pthread_join(haria_timer1, NULL);
    pthread_join(haria_timer2, NULL);

    return 0;
}
