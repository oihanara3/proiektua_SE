#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "../include/prozesu_sortzailea.h"
#include "../include/prozesuak.h"

/*
 * Prozesu sortzailea hasieratu.
 *  - Erlojuarekiko eta ilara nagusiarekiko lotura egiten da.
 *  - Gure ausazko sortzailearen hazia hasieratzen da (time + pid).
 */
void prozesu_sortzailea_hasieratu(struct ProzesuSortzailea *s,
                                  struct Erlojua *e,
                                  struct ProzesuIlara *ilara) {
    s->lotutako_erlojua = e;
    s->ilara = ilara;
    s->azken_pid = 0;

    unsigned int seed = (unsigned int)(time(NULL) ^ getpid());
    prozesu_ausazko_hasiera(seed);
    printf("[SORTZAILEA] Gure ausazko hazia hasieratu da: %u\n", seed);
}

/*
 * Tenporizadoreak seinalea bidaltzen duen tick bakoitzean deitzen den funtzioa.
 * PID berria esleitu, PCB sortu, READY egoerara jarri eta ilara nagusian txertatzen da.
 */
void prozesu_sortzailea_tick(struct ProzesuSortzailea *ps) {
    if (!ps) return;

    ps->azken_pid++;

    struct PCB *p = sortu_prozesua(ps->azken_pid);
    p->egoera = PROC_READY;

    ilarara_sartu(ps->ilara, p);
}
